
<h1><?php echo $titre; ?></h1>
<br/>


	
<div class="container">         
  <table class="table">
    <thead>
      <tr>
        <th>Pseudo</th>
	<th>Nom</th>
	<th>Prenom</th>
      </tr>
    </thead>
<?php
foreach($logins as $pseudo)
	{
	echo "<tbody>";
	echo "<tr>";
	echo "<th><h5>",$pseudo["CPT_pseudo"],"</h5></th>";
	echo "<th><h5>",$pseudo["PRF_nom"],"</h5></th>";
	echo "<th><h5>",$pseudo["PRF_prenom"],"</h5></th>";
	echo "</tr>";
	echo "</tbody";
	echo "</tr>";

	}
?>

  </table>
</div>

<!--
<?php
foreach($logins as $pseudo)
	{
	echo "<br/>";
	echo " -- ";
	echo $pseudo["CPT_pseudo"];
	echo " -- ";
	echo "<br/>";
	}
?>
-->

