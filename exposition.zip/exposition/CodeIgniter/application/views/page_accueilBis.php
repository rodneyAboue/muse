<?php

$saut = "<br/>";

echo ("Page Web OK ");
echo $saut;

// Connexion à la base MariaDB
$mysqli = new mysqli('localhost','opacho','337n46bd','znl3-zcreuxth0');
if ($mysqli->connect_errno) {
//...
 echo ("Probleme lors de la connexion");
echo $saut;
}
?>


<div class="events">
		<div class="container">
			<h3>Actus</h3>
				<div class="events-grids">

<?php

$mesActu = "SELECT * FROM ACTUALITE join TJ_ACT_ORI using (ACT_id) join ORIGINAL using (ORI_id) ORDER by ACT_id DESC LIMIT 5";
echo $mesActu;
echo $saut;

if ($resultMesActu = $mysqli->query($mesActu))
	{
		/* Détermination et affichage du nombre de lignes du résultat */ 
		$row_cnt = $resultMesActu->num_rows;
		//echo($row_cnt);

    		/* Récupération d'un tableau associatif */
		while ($row = $resultMesActu->fetch_assoc())
			{
				//printf ("%s (%s)\n", $row["ACT_titre"], $row["ACT_contenue"]);
?>
<div class="col-md-3 event-grid">
						<a href="#" class="mask">
						<img src="<?php echo $row["ORI_image"] ?>" class="img-responsive zoom-img" alt=""></a>
					</div>
					<div class="col-md-3 event-grid1">
						<h4><?php echo $row["ACT_titre"],$saut,$saut ?> </h4>
						<h5><?php echo $row["ACT_date"],$saut,$saut ?></h5>
						<p><?php echo $row["ACT_contenue"],$saut,$saut ?></p>
					</div>

<?php


				
			}
	}

?>

				</div>
		</div>

<div class="events">
		<div class="container">
			<h3>Une commande</h3>
			<div class="events-grids">

<?php

$maCommande = "SELECT * FROM COMMANDE where COM_id = 1";
echo $maCommande;
echo $saut;

if ($resultMesActu = $mysqli->query($maCommande))
	{
    		/* Récupération d'un tableau associatif */
		while ($row = $resultMesActu->fetch_assoc())
			{
				//printf ("%s (%s) %s\n", $row["COM_nom"], $row["COM_prenom"], $row["COM_mail"]);
?>


				<div class="col-md-3 event-grid">
					<a href="#" class="mask">
					<img src="images/e1.jpg" class="img-responsive zoom-img" alt=""></a>
				</div>
				<div class="col-md-3 event-grid1">
					<h4><?php echo $row["COM_codeCommande"] ?></h4>
					<h4><?php echo $row["COM_nom"], $row["COM_prenom"] ?></h4>
					<h5><?php echo $row["COM_mail"] ?></h5>
					<p><?php echo $row["COM_date"],$row["COM_prix"] ?></p>

<?php

$maCommandeDetail = "SELECT * FROM TJ_GOO_COM join GOODIE using (GOO_id) where COM_id = 1";
echo $maCommandeDetail;
echo $saut;

if ($resultMesActuDetail = $mysqli->query($maCommandeDetail))
	{
		/* Récupération d'un tableau associatif */
		while ($rowDetail = $resultMesActuDetail->fetch_assoc())
			{
			?>
			<p><?php echo $rowDetail["GOO_nom"],$rowDetail["GOO_nb"],$rowDetail["GOO_prix"] ?></p>

			<?php
			}
	}
?>
				</div>
<?php


				
			}
	}

?>

	</div>
</div>


<?php
//Fermeture de la communication avec la base MariaDB
$mysqli->close();

?>


