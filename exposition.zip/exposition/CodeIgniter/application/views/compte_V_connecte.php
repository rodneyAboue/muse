

<h2>Espace d'administration</h2>
<br />
<h2>Session ouverte!</h2>

<?php

$pseudo = $_SESSION['username'];
echo $pseudo;
?>
