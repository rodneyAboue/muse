<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Login</title>
		<link rel="icon" href="<?php echo base_url();?>style/img/favicon.ico">
		<!-- CSS FILES -->
		<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/uikit@latest/dist/css/uikit.min.css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>style/css/login-dark.css">
	</head>
	<body class="login uk-cover-container uk-background-secondary uk-flex uk-flex-center uk-flex-middle uk-height-viewport uk-overflow-hidden uk-light" data-uk-height-viewport>
		<!-- overlay -->
		<div class="uk-position-cover uk-overlay-primary"></div>
		<!-- /overlay -->
		<div class="uk-position-bottom-center uk-position-small uk-visible@m uk-position-z-index">
			<span class="uk-text-small uk-text-muted">© 2020 Create by: ABOUE KENNETH | Built with <a href="http://getuikit.com" title="Visit UIkit 3 site" target="_blank" data-uk-tooltip><span data-uk-icon="uikit"></span></a></span>
		</div>
		<div class="uk-width-medium uk-padding-small uk-position-z-index" uk-scrollspy="cls: uk-animation-fade">
			
			<div class="uk-text-center uk-margin">
				<img src="<?php echo base_url();?>style/img/login-logo.svg" alt="Logo">
			</div>

			<!-- login -->
			<?php
			if (isset ($test))
			{
				if (validation_errors())
				{
				 	echo "Erreur: Veuillez remplir le formulaire s’affiche ";
				}
				else
				{
					echo "Erreur: Echec d’authentification, veuillez réessayez" ;
				}
			}
			else{
				if (validation_errors())
				{
					echo "Erreur: Veuillez remplir le formulaire s’affiche ";
				}
			}
			?>
			<?php
				echo form_open('compte/create')  
				echo "Data ". $titre;
			?>

				<div class="uk-margin-small">
					<div class="uk-inline uk-width-1-1">
						<span class="uk-form-icon uk-form-icon-flip" data-uk-icon="icon: mail"></span>
						<input class="uk-input uk-border-pill" placeholder="E-mail" required type="text" name="mail">
					</div>
				</div>
				<div class="uk-margin-small">
					<div class="uk-inline uk-width-1-1">
						<span class="uk-form-icon uk-form-icon-flip" data-uk-icon="icon: user"></span>
						<input class="uk-input uk-border-pill" placeholder="Name" required type="text" name="name">
					</div>
				</div>
				<div class="uk-margin-small">
					<div class="uk-inline uk-width-1-1">
						<span class="uk-form-icon uk-form-icon-flip" data-uk-icon="icon: user"></span>
						<input class="uk-input uk-border-pill" placeholder="Surname" required type="text" name="surname">
					</div>
				</div>
				<div class="uk-margin-small">
					<div class="uk-inline uk-width-1-1">
						<span class="uk-form-icon uk-form-icon-flip" data-uk-icon="icon: lock"></span>
						<input class="uk-input uk-border-pill" placeholder="Password" required type="text" name="password1">
					</div>
				</div>
				<div class="uk-margin-small">
					<div class="uk-inline uk-width-1-1">
						<span class="uk-form-icon uk-form-icon-flip" data-uk-icon="icon: lock"></span>
						<input class="uk-input uk-border-pill" placeholder="Confirm password" required type="text" name="password2" >
					</div>
				</div>
				<div class="uk-margin-bottom">
					<button type="submit" class="uk-button uk-button-primary uk-border-pill uk-width-1-1">Create account</button>
				</div>
			</form>
			<!-- /recover password -->
			
			<!-- action buttons -->
			<div>
				<div class="uk-text-center">
					<a class="uk-link-reset uk-text-small toggle-class" data-uk-toggle="target: .toggle-class ;animation: uk-animation-fade" href="<?php echo base_url();?>index.php/compte/connection"> <span data-uk-icon="arrow-left"></span>Back to login</a>
				</div>
			</div>
			<!-- action buttons -->
		</div>
		
		<!-- JS FILES -->
		<script src="https://cdn.jsdelivr.net/npm/uikit@latest/dist/js/uikit.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/uikit@latest/dist/js/uikit-icons.min.js"></script>
	</body>
</html>