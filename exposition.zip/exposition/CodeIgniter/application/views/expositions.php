<div class="uk-overflow-auto">
	<table class="uk-table uk-table-responsive uk-table-divider">
		<thead>
    		<tr>
        		<th>id</th>
				<th>theme</th>
				<th>statut</th>
        		<th>date debut</th>
        		<th>date fin</th>
        		<th>Login</th>
        		<th>suppression</th>
				<th>modifier</th>
      		</tr>
    	</thead>
		<?php
		foreach($expositions as $exposition)
		{
			echo "<tbody>";
			echo "<tr>";
			echo "<th><h5>",$exposition["id"],"</h5></th>";
			echo "<th><h5>",$exposition["theme"],"</h5></th>";
			echo "<th><h5>",$exposition["statut"],"</h5></th>";
			echo "<th><h5>",$exposition["debut"],"</h5></th>";
			echo "<th><h5>",$exposition["fin"],"</h5></th>";
			echo "<th><h5>",$exposition["login"],"</h5></th>";
			echo "<td><button class=".'"uk-button uk-button-danger"' ."type=" .'"button"' . ">supprimer</button></td>";
			echo "<td><button class=".'"uk-button uk-button-default"' ."type=" .'"button"' . ">modifier</button></td>";
			echo "</tr>";
			echo "</tbody";
			echo "</tr>";
		}
		?>
	</table>
	
</div>
