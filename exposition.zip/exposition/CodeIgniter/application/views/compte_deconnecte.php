
<?php

	if (isset($_SESSION['username']))	
	{
		header("Location: " .base_url() ."index.php/compte/connection");
	}
	else
	{
		header("Location: " .base_url() ."index.php/compte/connection");
	}
	
?>
