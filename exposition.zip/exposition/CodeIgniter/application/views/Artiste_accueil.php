<div class=uk-grid uk-grid-medium data-uk-grid>
<?php
	foreach ($news as $new ) {
		echo "<div>";
		echo "<div class=".'"uk-card uk-card-default. uk-card-small"' . ">";
		echo "<div class=" . '"uk-card-media-top"' . ">";
		echo "<div class=" . '"uk-inline-clip uk-transition-toggle uk-light"' . ">";
		echo "<img src=" . '"' . $new['image'] .  '"' . "alt=" . '"I´m the image title"' . ">";
		echo "<div class=" . '"uk-transition-fade uk-position-cover uk-overlay uk-overlay-primary uk-flex uk-flex-center uk-flex-middle"' . ">";
		echo "</div>";
		echo "</div>";
		echo "</div>";
		echo "<div class=" . '"uk-card-header"' . ">";
		echo "<div class=" . '"uk-grid-small uk-flex uk-flex-middle"'. "data-uk-grid>";
		echo "<div class=" . '"uk-width-expand"' . ">";
		echo "<h5 class=" . '"uk-margin-remove-bottom"' . ">" . $new['texte'] ."</h5>";	
		echo "<p class=" . '"uk-text-meta uk-margin-remove"' . ">Taken: " . $new['date'] . "</p>";
		echo "<p class=" . '"uk-text-meta uk-margin-remove"' . ">By: " . $new['login'] . "</p>";
		echo "</div>";
		echo "</div>";
		echo "</div>";
		echo "</div>";
		echo "</div>";
	}
	
?>
</div>			