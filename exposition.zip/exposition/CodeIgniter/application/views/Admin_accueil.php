  <table  class="uk-table uk-table-responsive uk-table-divider">
    <thead>
    <tr>
    <th>Image</th>
    <th>texte</th>
	<th>id</th>
	<th>login</th>
	<th>date</th>
	<th>statut</th>
	<th>suppression</th>
	<th>modifier</th>
      </tr>
    </thead>
<?php
foreach($news as $new)
	{
	echo "<tbody>";
	echo "<tr>";
	echo "<th><h5><a href='".$new["image"]."'> aficher</a></h5></th>";
	echo "<th><h5>".$new["texte"]."</h5></th>";
	echo "<th><h5>".$new["id"]."</h5></th>";
	echo "<th><h5>".$new["login"]."</h5></th>";
	echo "<th><h5>".$new["date"]."</h5></th>";
	echo "<th><h5>".$new["statut"]."</h5></th>";
	echo "<td><a class=".'"uk-button uk-button-danger"' ."type=" .'"button"' ."href=".'"' .base_url()."index.php/actualite/delete/".$new["id"].'"'. ">supprimer</a></td>";
	echo "<td><a class=".'"uk-button uk-button-default"' ."type=" .'"button"' ."href=".'"' .base_url()."index.php/actualite/changeActive/".$new["id"]."/".$new["statut"].'"'. ">modifier</a></td>";
	echo "</tr>";
	echo "</tbody";
	echo "</tr>";

	}
?>

  </table>
