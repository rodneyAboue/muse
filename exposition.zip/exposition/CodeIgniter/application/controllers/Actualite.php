<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Actualite extends CI_Controller {
        
	public function __construct()
    {
        parent::__construct();
		$this->load->model('db_model');
        $this->load->helper('url_helper');
    }
    public function home()
	{
		$data['info']=$this->db_model->get_profil($_SESSION['username']);

		if (isset($_SESSION['username']))	
		{
			$data['profil']=$this->db_model->get_profil($_SESSION['username']);
   			//echo $_SESSION['username'];
   			$data['news']=$this->db_model->get_all_news();
   			$statut= $this->db_model->get_statut($_SESSION['username']);
   			//echo $statut->statutProfil;
   			$this->load->view('templates/haut'."_".$statut->statutProfil,$data);
   		    $this->load->view($statut->statutProfil.'_accueil',$data);
	   	    $this->load->view('templates/bas');
		}
		else
		{
			header("Location: " .base_url() ."index.php/compte/connection");
		}
 	}

 	public function changeActive($id,$etat)
	{
		
		if (isset($_SESSION['username']))	
		{
			if ($etat=='D') 
			{
				$statut= $this->db_model->set_new($id,'A');
			}
			else 
			{
				$statut= $this->db_model->set_new($id,'D');
			}
			header("Location: " .base_url() ."index.php/actualite/home");
		}
		else
		{
			header("Location: " .base_url() ."index.php/compte/connection");
		}
	}

	public function delete($id)
	{
		
		if (isset($_SESSION['username']))	
		{
			if ($this->db_model->new_exist($id)) 
			{
				$statut= $this->db_model->delete_new($id,'A');
			}
			header("Location: " .base_url() ."index.php/actualite/home");
		}
		else
		{
			header("Location: " .base_url() ."index.php/compte/connection");
		}
	}

}
?>
