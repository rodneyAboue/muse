
<?php

	if (isset($_SESSION['username']))	
	{
		$pseudo = $_SESSION['username'];
		echo $pseudo;
	}
	else
	{
		header("Location: " .base_url() ."index.php/compte/connection");
	}
?>
