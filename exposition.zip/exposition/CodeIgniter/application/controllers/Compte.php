<?php
class Compte extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('db_model');
		$this->load->helper('url_helper');
	}

	public function create_hash_word($longueur )
	{
 		$caracteres = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
 		$longueurMax = strlen($caracteres);
 		$chaineAleatoire = '';
 	
 		for ($i = 0; $i < $longueur; $i++)
		{
		 	$chaineAleatoire =$chaineAleatoire.$caracteres[random_int(0, $longueurMax - 1)];
 		}

 		return $chaineAleatoire;
	}


	public function lister()
	{
		$data['titre']='Comptes';
		$data['logins']=$this->db_model->get_all_account();
		
		if ($this->db_model->is_admin($_SESSION['username']))
		{
			$statut= $this->db_model->get_statut($_SESSION['username']);
			$data['profil']=$this->db_model->get_profil($_SESSION['username']);
			$this->load->view('templates/haut'."_".$statut->statutProfil,$data);
   	    	$this->load->view('compte_liste',$data);
   	    	$this->load->view('templates/bas');
		}
		else
		{
			$this->load->view('templates/login');
		}
	}


    public function create()
	{
		$this->load->helper('form');
 		$this->load->library('form_validation');
		$this->form_validation->set_rules('name', 'name', 'required');
		$this->form_validation->set_rules('surname', 'surname', 'required');
		$this->form_validation->set_rules('mail', 'mail', 'required' );
		$this->form_validation->set_rules('login', 'login', 'required' );
 		$this->form_validation->set_rules('password1', 'password1', 'required');
		$this->form_validation->set_rules('password2', 'password2', 'required');
		if ($this->form_validation->run() == FALSE)
	 	{
	       	$this->load->view('create_account');
	 	}
		else
 		{
			$mdp1=$this->input->post('password1');
			$mdp2=$this->input->post('password2');
			$name=$this->input->post('name');
			$surname=$this->input->post('surname');
    		$login=$this->input->post('login');
    		$mail=$this->input->post('mail');
			if (strcmp($mdp1,$mdp2) != 0 || $this->db_model->login_exist($login))
			{
				echo "les 2 mots de passe saisis sont différents ou login existant ";
    	   		$this->load->view('create_account');
			}
			else
			{	
				$statut="Invite";
				$activation="desactive";
				$taille=64-strlen($mdp1);
				//echo $taille;
				$myhash=$this->create_hash_word($taille);
				$this->db_model->add_account($login,$name,$surname,$mdp1,$mail,$statut,$activation,$myhash);
				$this->load->view('create_account_answer');
		 	}
		}
	}

	public function connection()
	{
		$this->load->helper('form');
	 	$this->load->library('form_validation');
		$this->form_validation->set_rules('login', 'login', 'required');
	 	$this->form_validation->set_rules('password', 'password', 'required');

		if ($this->form_validation->run() == FALSE)
	 	{
	       	$this->load->view('templates/login');
	 	}
		else
	 	{
			$username=$this->input->post('login');
			$mdp=$this->input->post('password');
			$tmp_hash=$this->db_model->get_hash($username);
			$password=hash('sha256', $tmp_hash->hash.$mdp);
			//echo $password;
			if ($this->db_model->try_connect($username,$password))
	     	{

				$session_data = array('username'=>$username);
				$this->session->set_userdata($session_data);
   		  		$this->load->view('imconnected');	
			}
			else
			{
				$this->load->view('templates/login');
			}

		}
	}


	public function deconnection()
	{
		$this->session->set_userdata('username');
		$this->load->view('compte_deconnecte');
	}
	
	/*public function update()
	{
			$name="Neal";
			echo "Before";
			echo "</br>";
			$my_password=$this->db_model->get_password($name);
			echo "sans hash : ".$my_password->password;
			echo "</br>";
			$taille=64-strlen($my_password->password);
			echo "taille: ".$taille;
			echo "</br>";
			$myhash=$this->create_hash_word($taille);
			echo "myhash que je viens de creer : ".$myhash;
			$this->db_model->update_password($name,$my_password->password,$myhash);
			echo "</br>";
			echo "After ";
			echo "</br>";
			$my_password=$this->db_model->get_password($name);
			echo "password avec hash ".$my_password->password;
			echo "</br>";
			$my_hash=$this->db_model->get_hash($name);
			echo "mon hash: ".$my_hash->hash;
			echo "</br>";
			echo "verif :".hash('sha256',$my_hash->hash."1234");
	}*/


}

?>
