
  <table  class="uk-table uk-table-responsive uk-table-divider">
    <thead>
      <tr>
    <th>login</th>
	<th>surame</th>
	<th>name</th>
	<th>mail</th>
	<th>statut</th>
	<th>activation</th>
	<th>suppression</th>
	<th>activation/desactivation</th>
      </tr>
    </thead>
<?php
foreach($logins as $login)
	{
	echo "<tbody>";
	echo "<tr>";
	echo "<th><h5>".$login["login"]."</h5></th>";
	echo "<th><h5>".$login["nom"]."</h5></th>";
	echo "<th><h5>".$login["prenom"]."</h5></th>";
	echo "<th><h5>".$login["mail"]."</h5></th>";
	echo "<th><h5>".$login["statutProfil"]."</h5></th>";
	echo "<th><h5>".$login["activation"]."</h5></th>";
	echo "<td><button class=".'"uk-button uk-button-danger"' ."type=" .'"button"' . ">supprimer</button></td>";
	echo "<td><button class=".'"uk-button uk-button-default"' ."type=" .'"button"' . ">Activer/desactiver</button></td>";
	echo "</tr>";
	echo "</tbody";
	echo "</tr>";

	}
?>

  </table>
