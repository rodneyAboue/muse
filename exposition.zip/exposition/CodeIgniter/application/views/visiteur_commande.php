	 <div class="content">
 		<div class="contact">
 			<div class="container">
		 			
				<div class="contact_top">
			 		<div class="col-md-8 contact_left">

<?php echo form_open('commande/ouvrir'); ?>
	<p>Verifiez votre commande</p>
 	<div class="form_details">
			<input type="text" name="commande" placeholder="commande" required="required">
			<input type="text" name="identification" placeholder="identification" required="required">
			<div class="clearfix"> </div>
		<div class="sub-button">
			<input type="submit" value="Valider">
		</div>
	</div>
</form>
						  
				 </div>
			</div>
		</div>
	</div>
	</div>	