<table  class="uk-table uk-table-responsive uk-table-divider">
    <thead>
	    <tr>
		    <th>Image</th>
    		<th>nom</th>
			<th>descriptif</th>
			<th>exposition</th>
			<th>prix</th>
			<th>statut</th>
			<th>suppression</th>
			<th>modifier</th>
      </tr>
    </thead>
	<?php
		foreach($tableaux as $tableau)
		{
			echo "<tbody>";
			echo "<tr>";
			echo "<th><h5><a href='".$tableau["image"]."'> aficher</a></h5></th>";
			echo "<th class=".'"uk-text-truncate"' . "><h5>".$tableau["nom"]."</h5></th>";
			echo "<th><h5>".$tableau["descriptif"]."</h5></th>";
			echo "<th><h5>".$tableau["exposition_id"]."</h5></th>";
			echo "<th><h5>".$tableau["prix"]."</h5></th>";
			echo "<th><h5>".$tableau["statut"]."</h5></th>";
			echo "<td><button class=".'"uk-button uk-button-danger"' ."type=" .'"button"' . ">supprimer</button></td>";
			echo "<td><button class=".'"uk-button uk-button-default"' ."type=" .'"button"' . ">modifier</button></td>";
			echo "</tr>";
			echo "</tbody";
			echo "</tr>";
		}
	?>

</table>
