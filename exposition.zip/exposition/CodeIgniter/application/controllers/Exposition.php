<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Exposition extends CI_Controller {
        
	public function __construct()
    {
        parent::__construct();
		$this->load->model('db_model');
        $this->load->helper('url_helper');
    }
    
    public function show()
	{
		//$data['info']=$this->db_model->get_profil($_SESSION['username']);
		
		if (isset($_SESSION['username']))	
		{
			$data['profil']=$this->db_model->get_profil($_SESSION['username']);
   			$data['expositions']=$this->db_model->get_all_expositions();
   			$statut= $this->db_model->get_statut($_SESSION['username']);
   			$this->load->view('templates/haut'."_".$statut->statutProfil,$data);
   		    $this->load->view('expositions',$data);
	   	    $this->load->view('templates/bas');
		}
		else
		{
			$this->load->view('templates/login');
		}
		
 	}

}
?>
