   <div class="content">
    <div class="contact">
      <div class="container">
          
        <div class="contact_top">
          <div class="col-md-8 contact_left">
<?php echo validation_errors(); ?> 
  <?php echo form_open('compte/creer'); ?>
   <p>Creation compte</p>
    <div class="form_details">
    <input type="text" name="nom" placeholder="nom" required="required" />
    <input type="text" name="prenom" placeholder="prenom" required="required" />
    <input type="text" name="email" placeholder="E-mail" />
    <input type="text" name="mdp1" placeholder="nouveau mot de passe" />
    <input type="text" name="mdp2" placeholder="confirmer nouveau mot de passe" />
    <input type="text" name="statut" placeholder="Statut" />
    <input type="text" name="ptr" placeholder="point de retrait" />
    <input type="text" name="pseudo" placeholder="Entrer le pseudo" />
      <div class="clearfix"> </div>
    
    <input type="submit" name="submit" value="Creer" />
    <div class="sub-button">
    </div>
  </div>
</form>
         </div>
      </div>
    </div>
  </div>
  </div>  