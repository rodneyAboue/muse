   <div class="content">
    <div class="contact">
      <div class="container">
          
        <div class="contact_top">
          <div class="col-md-8 contact_left">
<h3>
<?php 

  echo "Mme/Mr :".$id->CMD_prenom_client ."  ". $id->CMD_nom_client ."";
  ?>
    
  </h3></br>


<br />



<div class="container">

  <table class="table">
    <thead>
      <tr>
        <th>Nom</th>
	       <th>Descriptif</th>
        <th>Prix</th>
        <th>Quantite</th>
      </tr>
    </thead>
<?php
foreach($com as $variable)
{
	echo "<tbody>";
	echo "<tr>";
	echo "<th><h5>".$variable["GOO_nom"]."</h5></th>";
	echo "<th><h5>".$variable["GOO_descriptif"]."</h5></th>";
	echo "<th><h5>".$variable["GOO_prix"]."</h5></th>";
	echo "<th><h5>".$variable["GOO_quantite"]."</h5></th>";
	echo "</tr>";
	echo "</tbody";
	echo "</tr>";

}

?>
<!---->
  </table>

<?php

echo("<h4>");
echo "total:".$id->CMD_prix;
echo ("</h4>");

?>
<a href="#" type="button" class="btn btn-danger">Supprimer ma commande</a>
</div>
         </div>
      </div>
    </div>
  </div>
  </div>  