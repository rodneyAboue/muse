
<?php

	if (isset($_SESSION['username']))	
	{
		$pseudo = $_SESSION['username'];
		header("Location: " .base_url() ."index.php/actualite/home");
	}
	else
	{
		header("Location: " .base_url() ."index.php/compte/connection");
	}
?>
