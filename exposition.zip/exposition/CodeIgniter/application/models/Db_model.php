<?php
class Db_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
/*
	
	public function get_an_actualite($numero)
	{
		$sql = $this->db->query("SELECT ACT_id, ACT_titre, ACT_contenu from ACTUALITE where ACT_id = $numero;");
		return $sql->row();
	}
	
*/
	public function get_all_news()
	{
		$sql = $this->db->query("SELECT * from actualite;");
		return $sql->result_array();
	}

	public function get_all_expositions()
	{
		$sql = $this->db->query("SELECT * from exposition;");
		return $sql->result_array();
	}
	public function get_all_tables()
	{
		$sql = $this->db->query("SELECT * from tableau;");
		return $sql->result_array();
	}
	public function get_all_account()
	{
		$sql=$this->db->query("SELECT * from compte join profil using(login);");

		return $sql->result_array();
	}
/*
	public function get_maxId()
	{
		$max = $this->db->query("SELECT max(PFL_id) as maxId from PROFIL;");
		return $max->row();
	}
*/

	public function add_account($login,$name,$surname,$mdp,$mail,$statut, $activation,$my_hash)
	{
		$password=hash('sha256', $my_hash.$mdp);
		$req_compte="INSERT INTO compte VALUES ('".addslashes($login)."','".addslashes($password)."','".addslashes($my_hash)."')";
		$query_compte = $this->db->query($req_compte);
		
		$req_profil="INSERT INTO profil VALUES ('".addslashes($name)."','".addslashes($surname)."',null,'".addslashes($mail)."','".addslashes($login)."','".addslashes($statut)."','".addslashes($activation)."',null);";			
		$query_profil = $this->db->query($req_profil);
		return 1;
	}
/*

	public function show_order_ids()
	{
		$cmd=$this->input->post('commande');
		$id=$this->input->post('identification');
		$show=$this->db->query("SELECT * FROM COMMANDE where CMD_identification= '".$id."' and CMD_commande = '".$cmd."';");

		return $show->row();
	}


	public function show_order()
	{
		$cmd=$this->input->post('commande');
		$id=$this->input->post('identification');
		$show=$this->db->query("SELECT * FROM COMMANDE left outer join tj_goodie_commande using (CMD_id) left outer join goodie using (GOO_id) 
		where CMD_identification= '".$id."' and CMD_commande = '".$cmd."';");

		return $show->result_array();
	}

*/
	public function try_connect($username, $password)
	{ 
		$active="active";
     	$query = $this->db->query("select * from compte join profil using (login) where login='".$username."' and password='".$password."' and activation= '" . $active . "';");
  		if($query->num_rows() > 0)  
        {  
			return true; 
        }  
        else  
        {  
			return false;
        }  
	}

	public function get_statut($username)
	{ 
    	$status=$this->db->query("Select statutProfil , activation from profil where login = '".$username."';");
		return $status->row();
	}

	public function get_profil($username)
	{ 
    	$status=$this->db->query("Select * from profil where login = '".$username."';");
		return $status->row();
	}

	public function login_exist($username)
	{ 
		$query = $this->db->query("select * from compte where login='".$username."';");
  		if($query->num_rows() > 0)  
        {  
			return true; 
        }  
        else  
        {  
			return false;
        } 
	}

	public function is_admin($username)
	{ 
		$admin="Admin";
		$query = $this->db->query("select * from profil where login='".$username."' and statutProfil='".$admin."';");
  		if($query->num_rows() > 0)  
        {  
			return true; 
        }  
        else  
        {  
			return false;
        } 
	}

	public function is_activate($username)
	{ 
		$admin="active";
		$query = $this->db->query("select * from profil where login='".$username."' and activation='".$admin."';");
  		if($query->num_rows() > 0)  
        {  
			return true; 
        }  
        else  
        {  
			return false;
        } 
	}
	public function get_hash($username)
	{
		$sql = $this->db->query("SELECT hash from compte where login='".$username."';");
		return $sql->row();
	}
	public function get_password($username)
	{
		$sql = $this->db->query("SELECT password from compte where login='".$username."';");
		return $sql->row();
	}
	public function find_null_hash()
	{
		$sql = $this->db->query("SELECT * from compte where hash='null';");
		return $sql->row();
	}
	public function update_password($login,$password,$hash)
	{
		$pass=hash('sha256', $hash.$password);	
		$this->db->query("Update compte set password = '".$pass."', hash = '".$hash."' where login = '".$login."';");
		return;
	}

	public function set_new($id,$etat)
	{
		$this->db->query("Update actualite set statut = '".$etat."' where id = '".$id."';");
		return;
	}
	
	public function delete_new($id)
	{
		$this->db->query("DELETE FROM actualite WHERE id= '".$id."';");
		return; 
	}

	public function new_exist($id)
	{ 
		$sql = $this->db->query("SELECT * from actualite WHERE id= '".$id."';");
  		if($sql->num_rows() > 0)  
        {  
			return true; 
        }  
        else  
        {  
			return false;
        } 
	}
/*
	public function update_profile_name($nom,$prenom,$mail)
	{
		$profil = $this->db_model->get_profil($_SESSION['username']);
		$this->db->query("Update PROFIL set PFL_prenom = '".$prenom."', PFL_nom = '".$nom."', PFL_mail = '".$mail."' 
					where PFL_id = '".$profil->PFL_id."';");
		return 1;
	}


*/


}
?>
