<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Exposition</title>
		<!-- CSS FILES -->
		<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/uikit@latest/dist/css/uikit.min.css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>style/css/dashboard.css">
	</head>
	<body>
<?php

	if (!isset($_SESSION['username']))	
	{
		header("Location: " .base_url() ."index.php/compte/connection");
	}
?>

		<!--HEADER-->
		<header id="top-head" class="uk-position-fixed">
			<div class="uk-container uk-container-expand uk-background-primary">
				<nav class="uk-navbar uk-light" data-uk-navbar="mode:click; duration: 250">
					<div class="uk-navbar-left">
						<div class="uk-navbar-item uk-hidden@m">
							<a class="uk-logo" href="<?php echo base_url();?>index.php/actualite/home"><img class="custom-logo" src="img/dashboard-logo-white.svg" alt=""></a>
						</div>
						<ul class="uk-navbar-nav uk-visible@m">
							<li><a href="<?php echo base_url();?>index.php/actualite/home" ><span data-uk-icon="icon: home" class="uk-margin-small-right"></span>Accueil</a></li>
							<li><a href="<?php echo base_url();?>index.php/exposition/show"><span data-uk-icon="icon: album" class="uk-margin-small-right"></span>Les expositions</a></li>
							<li><a href="<?php echo base_url();?>index.php/tableau/show"><span data-uk-icon="icon: image" class="uk-margin-small-right"></span>Les tableaux</a></li>
							<li><a href="<?php echo base_url();?>index.php/compte/lister"><span data-uk-icon="icon: users" class="uk-margin-small-right"></span>Les comptes</a></li>
						</ul>
						<div class="uk-navbar-item uk-visible@s">
							<form action="dashboard.html" class="uk-search uk-search-default">
								<span data-uk-search-icon></span>
								<input class="uk-search-input search-field" type="search" placeholder="Search">
							</form>
						</div>

					</div>
					<div class="uk-navbar-right">
						<div class="uk-navbar-item">
							<a class="uk-navbar-toggle uk-hidden@m" data-uk-toggle data-uk-navbar-toggle-icon href="#offcanvas-nav"></a>
							<a href="<?php echo base_url();?>index.php/compte/deconnection" class="uk-button uk-button-secondary uk-visible@m"><span data-uk-icon="sign-out"></span>SIGN OUT</a>
						</div>
					</div>
				</nav>
			</div>
		</header>
		<aside id="left-col" class="uk-light uk-visible@m">
			<div class="left-logo uk-flex uk-flex-middle">
				<a href="<?php echo base_url();?>index.php/actualite/home" >
					<img class="custom-logo" src="<?php echo base_url();?>style/img/dashboard-logo.svg" alt="" >
				</a>
			</div>
			<div class="left-content-box  content-box-dark">
				<img src="<?php echo base_url();?>style/img/avatar.svg" alt="" class="uk-border-circle profile-img">
				<h4 class="uk-text-center uk-margin-remove-vertical text-light"><?= $profil->nom ?> <?= $profil->prenom ?></h4>
				<h7 class="uk-text-center uk-margin-remove-vertical text-light"><?= $profil->mail ?></h7>
				<div class="uk-position-relative uk-text-center uk-display-block">
				    <a href="#" class="uk-text-small uk-text-muted uk-display-block uk-text-center" data-uk-icon="icon: triangle-down; ratio: 0.7"><?= $profil->statutProfil ?></a>
				</div>
			</div>
			
			<div class="left-nav-wrap">
				<ul class="uk-nav uk-nav-default uk-nav-parent-icon" data-uk-nav>
					<li class="uk-nav-header">DESACTIVATION</li>
					<li><a href="<?php echo base_url();?>index.php/compte/lister"><span data-uk-icon="icon: user" class="uk-margin-small-right"></span>desactiver un compte</a></li>
					<li><a href="<?php echo base_url();?>index.php/actualite/home"><span data-uk-icon="icon: comment" class="uk-margin-small-right"></span>desactiver actualité</a></li>
				</ul>
				<ul class="uk-nav uk-nav-default uk-nav-parent-icon" data-uk-nav>
					<li class="uk-nav-header">ACTION SUPPRESSION</li>
					<li><a href="<?php echo base_url();?>index.php/actualite/home"><span data-uk-icon="icon: comment" class="uk-margin-small-right"></span>Suprimer un actualite</a></li>
					<li><a href="<?php echo base_url();?>index.php/tableau/show"><span data-uk-icon="icon: image" class="uk-margin-small-right"></span>Suprimer un tableau</a></li>
					<li><a href="<?php echo base_url();?>index.php/exposition/show"><span data-uk-icon="icon: album" class="uk-margin-small-right"></span>Suprimer une exposition </a></li>
					<li><a href="<?php echo base_url();?>index.php/compte/lister"><span data-uk-icon="icon: user" class="uk-margin-small-right"></span>Suprimer un compte </a></li>
				</ul>
				
			</div>
			<div class="bar-bottom">
				<ul class="uk-subnav uk-flex uk-flex-center uk-child-width-1-5" data-uk-grid>	
					<li>
						<a href="<?php echo base_url();?>index.php/compte/deconnection" class="uk-icon-link" data-uk-tooltip="Sign out" data-uk-icon="icon: sign-out"></a>
					</li>
				</ul>
			</div>
		</aside>
		<!-- /LEFT BAR -->
		<!-- CONTENT -->
		<div id="content" data-uk-height-viewport="expand: true">
			<div class="uk-container uk-container-expand">
				<hr>
