	 <div class="content">
 		<div class="contact">
 			<div class="container">
		 			
				<div class="contact_top">
			 		<div class="col-md-8 contact_left">
<?php

if (isset ($test))
{
	if (validation_errors())
		{
		 echo "Veuillez remplir le formulaire s’affiche ";
		}
	else
		{
		echo "Echec d’authentification, veuillez réessayez" ;
		}
}
else
{
	if (validation_errors())
		{
		 echo "Veuillez remplir le formulaire s’affiche ";
		}
}

?>


<?php echo form_open('compte/connection'); ?>
	<p>Connectez-vous</p>
 	<div class="form_details">
		<input type="text" name="pseudo" placeholder="pseudo" required="required">
			<input type="text" name="mdp" placeholder="mot de passe">
			<div class="clearfix"> </div>
		<div class="sub-button">
			<input type="submit" value="Connexion">
		</div>
	</div>
</form>
						  
				 </div>
			</div>
		</div>
	</div>
	</div>	