<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Commande extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('db_model');
		$this->load->helper('url_helper');
	}

	public function ouvrir()
 	{
		$this->load->helper('form');
 		$this->load->library('form_validation');
		$this->form_validation->set_rules('identification', 'identification','required');
		$this->form_validation->set_rules('commande', 'commande','required');

		if ($this->form_validation->run() == FALSE)
 		{
        	$this->load->view('templates/haut');
        	$this->load->view('visiteur_commande');
        	$this->load->view('templates/bas');
 		}
		else
 		{
			if (!$com_id = $this->db_model->show_order())
			{
				$test['test']="test";
        		$this->load->view('templates/haut');
       	 		$this->load->view('visiteur_commande',$test);
        		$this->load->view('templates/bas');
 			}
			else 
			{
				
				$data['id'] = $this->db_model-> show_order_ids();
				$data['com'] = $this->db_model->show_order();
       			$this->load->view('templates/haut');
       			$this->load->view('visiteur_commande_succes',$data);
       			$this->load->view('templates/bas');
			}

		}

	}


}


?>

