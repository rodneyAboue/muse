<div class=uk-grid uk-grid-medium data-uk-grid>
<?php
	foreach ($tableaux as $tableau ) {
		echo "<div>";
		echo "<div class=".'"uk-card uk-card-default. uk-card-small"' . ">";
		echo "<div class=" . '"uk-card-media-top"' . ">";
		echo "<div class=" . '"uk-inline-clip uk-transition-toggle uk-light"' . ">";
		echo "<img src=" . '"' . $tableau['image'] .  '"' . "alt=" . '"I´m the image title"' . ">";
		echo "<div class=" . '"uk-transition-fade uk-position-cover uk-overlay uk-overlay-primary uk-flex uk-flex-center uk-flex-middle"' . ">";
		echo "</div>";
		echo "</div>";
		echo "</div>";
		echo "<div class=" . '"uk-card-header"' . ">";
		echo "<div class=" . '"uk-grid-small uk-flex uk-flex-middle"'. "data-uk-grid>";
		echo "<div class=" . '"uk-width-expand"' . ">";
		echo "<h5 class=" . '"uk-margin-remove-bottom"' . ">" . $tableau['nom'] ."</h5>";	
		echo "<div class=" . '"uk-text-left"' . ">Taken: " . $tableau['descriptif'] ."</div>";
		echo "<div class=" . '"uk-flex-right"' . ">Price : " . $tableau['prix'] . "$</div>";
		echo "<p class=" . '"uk-text-meta uk-margin-remove"' . ">Date: " . $tableau['date'] . "</p>";
		echo "</div>";
		echo "</div>";
		echo "</div>";
		echo "</div>";
		echo "</div>";
	}
	
?>
</div>			