

<?php

header("Location: " .base_url() ."index.php/compte/update");
?>
